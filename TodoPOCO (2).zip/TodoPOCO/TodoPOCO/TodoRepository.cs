﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TodoPOCO
{
    public class TodoRepository:
     ICreate<TodoItem>,
     IRead<TodoItem>,
     IUpdate<TodoItem>,
     IDelete<TodoItem>
    {
        private List<TodoItem> _items = new List<TodoItem>();

        public void Add(TodoItem item)
        {
            // TODO:  Add the item to the list
            item.Id = _items.Count;
            _items.Add(item);
        }

        public TodoItem? Get(int id)
        {
            // TODO: Find and return the item with this ID
            return (id >= 0 && id < _items.Count)
                ? _items[id]
                : null;
        }
        public List<TodoItem> GetAll()
        {
            // TODO:  Return every item in the list
            return _items;
        }

        public void Update(TodoItem item)
        {
            // TODO: Update the matching item in the list
            int index = _items.FindIndex(x => x.Id == item.Id);

            if (index >= 0)
                _items[index] = item;
        }

        public void Delete(int id)
        {
            // TODO: Remove the item with this ID
            int index = _items.FindIndex(x => x.Id == id);

            if (index >= 0)
                _items.RemoveAt(index);
        }
    }
    
}
